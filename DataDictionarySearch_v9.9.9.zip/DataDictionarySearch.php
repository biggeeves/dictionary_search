<?php
namespace DCC\DataDictionarySearch;

class DataDictionarySearch extends \ExternalModules\AbstractExternalModule {
	public function __construct() {
		parent::__construct();
		// Other code to run when object is instantiated
	}
	
	public function redcap_project_home_page( int $project_id ) {
		
	}

	
}